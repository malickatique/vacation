<h1>Hello, {{ $name }}</h1>
<p>I hope your are well, This is notification mail for your account on our site,</p>
<p>We have noticed that you are currently not active user on our site from long time,so for security reason we are
   <strong>disabling</strong> your account for temporary. 
</p>
<p>You will not allow to login until it again active.</p>
<p>For activation contact admin of site</p>


<h4>Thank Ypu</h4>
<h4>Regard's</h4>
<p>OVR Team</p>

