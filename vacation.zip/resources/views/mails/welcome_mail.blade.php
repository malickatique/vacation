<h2>Welcome, {{ $name }}</h2>
<p>You have been successfully registered, but account is not active yet</p>

<p>You profile is under review process, will be notifed soon.</p>

<h4>Thank You</h4>
<h4>Regard's</h4>
<p>OVR Team</p>

