<h1>Hello, {{ $name }}</h1>
<p>I hope your are well, This is notification mail for your account on our site,</p>

<p>Your profile has been active, you can login into account and post properties. <br> For login to site
    <a href="{{ url('/') }}">click here</a>
</p>

<p>Happy Sales</p>

<h4>Thank You</h4>
<h4>Regard's</h4>
<p>OVR Team</p>

