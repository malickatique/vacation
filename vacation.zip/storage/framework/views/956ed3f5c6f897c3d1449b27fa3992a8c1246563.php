<?php $__env->startSection('site-content'); ?>

<section class="hero_in contacts">
	<div class="wrapper">
		<div class="container">
			<h1 class="fadeInUp"><span></span>Properties</h1>
		</div>
	</div>
</section>

<div class="row my-5 mx-3">
    <div class="col-12 my-5">
        <form method="post" action="<?php echo e(action('PublicRequestsController@getSearchResults')); ?>">
            <?php echo e(csrf_field()); ?>

            <div class="row no-gutters custom-search-input-2">
                <div class="col-lg-4">
                    <div class="form-group">
                        <input class="form-control" type="text" name="lookingFor" placeholder="What are you looking for...">
                        <i class="icon_search"></i>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="form-group">
                        <input class="form-control" type="text" name="location" placeholder="Where">
                        <i class="icon_pin_alt"></i>
                    </div>
                </div>
                <div class="col-lg-3">
                    <select class="wide" name="cator">
                        <option value="all">All Categories</option>	
                        <option value="rent">Rent</option>
                        <option value="sale">Sale</option>
                    </select>
                </div>
                <div class="col-lg-2">
                    <input type="submit" class="btn_search" value="Search">
                </div>
            </div>
            <!-- /row -->
        </form>
    </div>
</div>

<div class="container margin_60_35">
    <div class="wrapper-grid">
        <div class="row">
        
            <?php if(count($properties) > 0): ?>
            <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <div class="col-xl-4 col-lg-6 col-md-6">
                    
                <div class="box_grid">
                    <figure>
                        <a href="#0" class="wish_bt"></a>
                        <a href="<?php echo e(route('single-property', $property->id)); ?>">

                            <?php if(empty($property->thumbnail)): ?>
                            <img src="<?php echo e(URL::to('/images/property/') .'/noImagefound.jpg'); ?>" class="img-fluid" alt="" width="800" height="533">
                            <?php else: ?> 
                            <img src="<?php echo e(URL::to('/images/property/' . $property->thumbnail)); ?>" class="img-fluid" alt="" width="800" height="533">
                            <?php endif; ?>

                            

                            
                            
                        
                            
                            
                            <div class="read_more"><span>Read more</span></div></a>
                    <small><?php echo e($property->name); ?> </small>
                    </figure>
                    <div class="wrapper">
                        <div class="cat_star"><i class="icon_star"></i><i class="icon_star"></i><i class="icon_star"></i><i class="icon_star"></i></div>
                    <h3><a href="<?php echo e(route('single-property', $property->id)); ?>"><?php echo e($property->name); ?></a></h3>
                        <p>
                            
                                <?php echo e(str_limit($property->description, $limit = 20, $end = '...')); ?></p>
                                
                        <span class="price">From <strong>$<?php echo e($property->per_night_rent); ?></strong> /per night</span>
                            <br>
                                
                        <span class="price">Posted by: <strong class="text-capitalize"><a href="#"><?php echo e($property->user->name); ?></a></strong></span>
                    </div>
                    
                </div>
            </div>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php else: ?>

            <h5>No properties found.</h5>

            <?php endif; ?>

            
            

            
            
        
        </div>
        <!-- /row -->
        </div>
        <!-- /wrapper-grid -->
        
        
        
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>