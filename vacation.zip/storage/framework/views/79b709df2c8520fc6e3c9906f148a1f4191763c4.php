<nav id="menu" class="main-menu">
        <ul>
            <li><span><a href="<?php echo e(URL::to('/')); ?>">Home</a></span></li>
            <li><span><a href="<?php echo e(route('show-properties')); ?>">Properties</a></span></li>

            <?php if(isset($navs)): ?>
                <?php $__currentLoopData = $navs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><span><a href="<?php echo e(URL::to('/page', $nav->slug)); ?>"><?php echo e($nav->name); ?></a></span></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

            

            <?php if(isset(Auth::user()->user_type)): ?>
                <?php if(Auth::user()->user_type == 'owner'): ?>

                
                     
                <?php endif; ?>
            <?php endif; ?>


            <?php if(isset(Auth::user()->user_type)): ?>
                <?php if(Auth::user()->user_type == 'owner' || Auth::user()->user_type == 'renter'): ?>
                    | <li class="text-capitalize"><span><a href="#"><?php echo e(Auth::user()->name); ?></a></span>
					<ul>
						<li><a href="<?php echo e(url('/renterDash')); ?>">Dashboard</a></li>
						<li><span><a href="<?php echo e(route('user.logout')); ?>">Logout</a></span></li>
					</ul>
				</li>  
                <?php endif; ?>
            <?php endif; ?>

           

        </ul>
    </nav>