<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="description" content="OVR - Owner Vacation Rentals">
      <meta name="author" content="Ansonika">
      <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
      <title>OVR | Owner Vacation Rentals</title>
     
      <link rel="apple-touch-icon" type="image/x-icon" href="img/apple-touch-icon-57x57-precomposed.png">
      <link rel="apple-touch-icon" type="image/x-icon" sizes="72x72" href="img/apple-touch-icon-72x72-precomposed.png">
      <link rel="apple-touch-icon" type="image/x-icon" sizes="114x114" href="img/apple-touch-icon-114x114-precomposed.png">
      <link rel="apple-touch-icon" type="image/x-icon" sizes="144x144" href="img/apple-touch-icon-144x144-precomposed.png">
      <!-- GOOGLE WEB FONT -->
      <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800" rel="stylesheet">
      <!-- BASE CSS -->
      <link href="<?php echo e(asset('site/css/bootstrap.min.css')); ?>" rel="stylesheet">
      <link href="<?php echo e(asset('site/css/style.css')); ?>" rel="stylesheet">
      <link href="<?php echo e(asset('site/css/vendors.css')); ?>" rel="stylesheet">
      <!-- YOUR CUSTOM CSS -->
      <link href="<?php echo e(asset('site/css/custom.css')); ?>" rel="stylesheet">
      <!-- Modernizr -->
      <script src="<?php echo e(asset('site/js/modernizr.js')); ?>"></script>

      <script src="<?php echo e(asset('site/js/jquery-3.3.1.slim.min.js')); ?>"></script>
      <script src="<?php echo e(asset('site/js/jquery-3.4.1.min.js')); ?>"></script>
      <!-- Data Range -->
      <script src="<?php echo e(asset('/js/jquery.min.js')); ?>"></script>
      <script src="<?php echo e(asset('/js/moment.min.js')); ?>"></script>
      <script src="<?php echo e(asset('/js/daterangepicker.min.js')); ?>"></script>
      <link href="<?php echo e(asset('/css/daterangepicker.css')); ?>" rel="stylesheet">
      
      <style>
      input.parsley-success,
   select.parsley-success,
   textarea.parsley-success {
   color: #468847;
   background-color: #DFF0D8;
   border: 1px solid #D6E9C6;
   }

   input.parsley-error,
   select.parsley-error,
   textarea.parsley-error {
   color: #B94A48;
   background-color: #F2DEDE;
   border: 1px solid #EED3D7;
   }

   .parsley-errors-list {
   margin: 2px 0 3px;
   padding: 0;
   list-style-type: none;
   font-size: 0.9em;
   line-height: 0.9em;
   opacity: 0;
   color: #B94A48;

   transition: all .3s ease-in;
   -o-transition: all .3s ease-in;
   -moz-transition: all .3s ease-in;
   -webkit-transition: all .3s ease-in;
   }

   .parsley-errors-list.filled {
   opacity: 1;
   }
</style>
   </head>
   <body>
      <div id="page">
         <header class="header menu_fixed">
            <div id="preloader">
               <div data-loader="circle-side"></div>
            </div>
            <!-- /Page Preload -->
            <div id="logo">
               <a href="<?php echo e(URL::to('/')); ?>">

                  <?php if(isset($logo)): ?>
                  <img src="<?php echo e(asset('images/setting/'.$logo->value )); ?>"  width="150" height="36" data-retina="true" alt="" class="logo_normal">
               <?php endif; ?>
               
               
               <?php if(isset($site_sticky_logo)): ?>
                  <img src="<?php echo e(asset('images/setting/'.$site_sticky_logo->value )); ?>" width="150" height="36" data-retina="true" alt="" class="logo_sticky">
               <?php endif; ?>
               </a>
            </div>
            <ul id="top_menu">
               
               <?php if(Auth::guest()): ?>
               	<li><a href="#sign-in-dialog" id="sign-in" class="login" title="Sign In">Sign In</a></li>
               <?php endif; ?>
               
            </ul>
            <!-- /top_menu -->
            <a href="#menu" class="btn_mobile">
               <div class="hamburger hamburger--spin" id="hamburger">
                  <div class="hamburger-box">
                     <div class="hamburger-inner"></div>
                  </div>
               </div>
            </a>
            <?php echo $__env->make('inc.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
         </header>
         <!-- /header -->
         
         <?php echo $__env->yieldContent('site-content'); ?>
         <!-- /main -->
         <footer>
            <div class="container margin_60_35">
               <div class="row">
                  <div class="col-lg-5 col-md-12 p-r-5">
                     <p>
                        <?php if(isset($footer_logo)): ?>
                        <img src="<?php echo e(asset('images/setting/'.$footer_logo->value )); ?>" width="150" height="36" data-retina="true" alt="">
                        <?php endif; ?>
                     </p>
                     <p><?php if(isset($footer_desc)): ?><?php echo e($footer_desc->value); ?><?php endif; ?></p>
                     
                  </div>
                  <div class="col-lg-3 col-md-6 ml-lg-auto">
                     <h5>Useful links</h5>
                     <ul class="links">
                        <li><a href="<?php echo e(URL::to('/login')); ?>">Login</a></li>
                        <li><a href="<?php echo e(URL::to('/register')); ?>">Register</a></li>
                        <?php if(isset($navs)): ?>
                        <?php $__currentLoopData = $navs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(URL::to('/page', $nav->slug)); ?>"><?php echo e($nav->name); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                     </ul>
                  </div>
                  <div class="col-lg-3 col-md-6">
                     <h5>Contact with Us</h5>
                     <ul class="contacts">
                        <li><a href="tel://61280932400"><i class="ti-mobile"></i><?php if(isset($footer_contact)): ?><?php echo e($footer_contact->value); ?><?php endif; ?></a></li>
                        <li><a href="mailto:info@Panagea.com"><i class="ti-email"></i><?php if(isset($footer_email)): ?><?php echo e($footer_email->value); ?><?php endif; ?></a></li>
                     </ul>
                     <div id="newsletter">
                        <h6>Newsletter</h6>
                        <div id="message-newsletter"></div>
                        <form method="post" action="assets/newsletter.php" name="newsletter_form" id="newsletter_form">
                           <div class="form-group">
                              <input type="email" name="email_newsletter" id="email_newsletter" class="form-control" placeholder="Your email">
                              <input type="submit" value="Submit" id="submit-newsletter">
                           </div>
                        </form>
                     </div>
                  </div>
               </div>
               <!--/row-->
               <hr>
               <div class="row">
                  <div class="col-lg-6">
                     <ul id="footer-selector">
                        <li>
                           <div class="styled-select" id="lang-selector">
                              <select>
                                 <option value="English" selected>English</option>
                                 <option value="French">French</option>
                                 <option value="Spanish">Spanish</option>
                                 <option value="Russian">Russian</option>
                              </select>
                           </div>
                        </li>
                        <li>
                           <div class="styled-select" id="currency-selector">
                              <select>
                                 <option value="US Dollars" selected>US Dollars</option>
                                 <option value="Euro">Euro</option>
                              </select>
                           </div>
                        </li>
                        <li><img src="<?php echo e(asset('site/img/cards_all.svg')); ?>" alt=""></li>
                     </ul>
                  </div>
                  <div class="col-lg-6">
                     <ul id="additional_links">
                        <li><a href="#0">Terms and conditions</a></li>
                        <li><a href="#0">Privacy</a></li>
                        <li><span><?php if(isset($footer_trademark)): ?><?php echo e($footer_trademark->value); ?><?php endif; ?>
                           </span>
                        </li>
                     </ul>
                  </div>
               </div>
            </div>
         </footer>
         <!--/footer-->
      </div>
      <!-- page -->
      <!-- Sign In Popup -->
      <div id="sign-in-dialog" class="zoom-anim-dialog mfp-hide">
         <div class="small-dialog-header">
            <h3>Sign In</h3>
         </div>
         <form method="POST" action="<?php echo e(route('login')); ?>">
            <div class="sign-in-wrapper">
               <?php echo e(csrf_field()); ?>

               <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                  <div class="form-group">
                     <label>Email</label>
                     <input type="email" class="form-control" name="email" id="email">
                     <i class="icon_mail_alt"></i>
                     <?php if($errors->has('email')): ?>
                     <span class="help-block">
                     <strong><?php echo e($errors->first('email')); ?></strong>
                     </span>
                     <?php endif; ?>
                  </div>
               </div>
               <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                  <div class="form-group">
                     <label>Password</label>
                     <input type="password" class="form-control" name="password" id="password" value="">
                     <i class="icon_lock_alt"></i>
                     <?php if($errors->has('password')): ?>
                     <span class="help-block">
                     <strong><?php echo e($errors->first('password')); ?></strong>
                     </span>
                     <?php endif; ?>
                  </div>
               </div>
               
               <div class="text-center"><input type="submit" value="Log In" class="btn_1 full-width"></div>
               <div class="text-center">
                  Don’t have an account? <a href="<?php echo e(URL::to('/select')); ?>">Sign up</a>
               </div>
            </div>
         </form>
         <!--form -->
      </div>
      <!-- /Sign In Popup -->
      <div id="toTop"></div>
      <!-- Back to top button -->
      <!-- COMMON SCRIPTS -->`
      <script src="<?php echo e(asset('plugins/repeater/jquery-1.11.1.js')); ?>"></script>`
      <script src="<?php echo e(asset('plugins/repeater/jquery.repeater.min.js')); ?>"></script>
      <script src="<?php echo e(asset('plugins/parsley/parsley.min.js')); ?>"></script>
      <script src="<?php echo e(asset('site/js/common_scripts.js')); ?>"></script>
      <script src="<?php echo e(asset('site/js/main.js')); ?>"></script>
      <script src="<?php echo e(asset('site/assets/validate.js')); ?>"></script>

   </body>
</html>