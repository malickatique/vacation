<?php $__env->startSection('site-content'); ?>

<main>
    <section class="hero_in restaurants_detail" >
        <div class="wrapper" >
            <div class="container">
            <h1 class="fadeInUp"><span></span><?php echo e($property->name); ?></h1>
            </div>
            <span class="magnific-gallery">

                <?php $__currentLoopData = $gallaries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(URL::to('/images/property/' . $gallary->media)); ?>" class="btn_photos" title="Photo title" data-effect="mfp-zoom-in">View photos</a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                
            </span>
        </div>
    </section>
    <!--/hero_in-->

    

    <div style="background-color: #F2F7FE;">
        <nav class="secondary_nav sticky_horizontal">
            <div class="container">
                <ul class="clearfix">
                    <li><a href="#description" class="active">Description</a></li>
                    <li><a href="#reviews">Reviews</a></li>
                    <li><a href="#sidebar">Booking</a></li>
                </ul>
            </div>
        </nav>
        <div class="container margin_60_35">
            <div class="row">
                <div class="col-lg-8">
                    <section id="description">

                        <h1><?php echo e($property->name); ?></h1>
                        <p><img src="<?php echo e(asset('site/img/map-marker.png')); ?>" alt="" style="width:15px; height: 18px;">
                            <?php echo e($property->address); ?>

                        </p>

                        <h2>For Sale: <span style="color:green;"> $<?php echo e($occasions[0]->per_night_rent); ?> </span></h2>
                        <hr>

                    <div class="card">
                        <div class="card-body">

                            <h2>Description</h2>
                            
                                <div class="row my-5">
                                    <div class="col-4">
                                        <img src="<?php echo e(asset('site/img/area.png')); ?>" style="width:35px; height: 35px;"> 
                                        <span> <b>Area:</b> <?php echo e($property->metadata->area); ?> sqft </span> 
                                    </div>
                                    <div class="col-4">
                                        <img src="<?php echo e(asset('site/img/beds.png')); ?>" style="width:35px; height: 35px;"> 
                                        <span> <b>Beds:</b> <?php echo e($property->metadata->bedrooms); ?> Bedrooms </span> 
                                    </div>
                                    <div class="col-4">
                                        <img src="<?php echo e(asset('site/img/rooms.png')); ?>" style="width:35px; height: 35px;"> 
                                        <span> <b>Type:</b> <?php echo e($property->metadata->type); ?> </span> 
                                    </div>
                                </div>
                                <div class="row my-5">
                                    <div class="col-4">
                                        <img src="<?php echo e(asset('site/img/baths.png')); ?>" style="width:35px; height: 35px;"> 
                                        <span> <b>Baths:</b> <?php echo e($property->metadata->bathrooms); ?> Bathrooms </span> 
                                    </div>
                                    <div class="col-4">
                                        <img src="<?php echo e(asset('site/img/floors.png')); ?>" style="width:35px; height: 35px;"> 
                                        <span> <b>Floors:</b> <?php echo e($property->metadata->floors); ?> Floors </span> 
                                    </div>
                                    <div class="col-4">
                                        <img src="<?php echo e(asset('site/img/garage.png')); ?>" style="width:35px; height: 35px;"> 
                                        <span> <b>Garage:</b> <?php echo e($property->metadata->garages); ?> Garages </span> 
                                    </div>
                                </div>

                                
                            <p><?php echo e($property->description); ?></p>

                        </div>
                    </div>
                        <hr>
                    <div class="card">
                        <div class="card-body">

                    <h5>Availability For Specific Occasions</h5><br>

                    <?php $__currentLoopData = $occasions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $occasion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <strong>Occasion Name:</strong>  <?php echo e($occasion->occasion_name); ?>| <p><strong>From:</strong> <?php echo e($occasion->availability_from); ?>  <strong>To:</strong> <?php echo e($occasion->availability_to); ?> for  <strong><span style="font-size:22px; color: green;">$<?php echo e($occasion->per_night_rent); ?></span></strong>  per night</p>
                        <hr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                    </div>
                    <hr>

                    <div class="card">
                        <div class="card-body">
                            <h5>Property Features</h5><br>
                            
                                <div class="row">
                                    <div class="col-lg-12">
                                        <ul class="bullets">
                                            <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($feature->feature->name); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                    </div>


                        <!-- /row -->
                        <hr>

                <div class="card">
                    <div class="card-body">
                        <h3>Address: </h3>
                        <p><img src="<?php echo e(asset('site/img/map-marker.png')); ?>" alt="" style="width:15px; height: 18px;">
                        <?php echo e($property->address); ?>

                        <div id="map" class="map map_single add_bottom_30">

                        </div>
                    </div>
                </div>
<script>
    // Initialize and add the map
    function initMap() {
        var geocoder, map;
        var address = "<?php echo $property->address ?>";
        codeAddress(address);
        function codeAddress(address) {
            geocoder = new google.maps.Geocoder();
            geocoder.geocode({
                'address': address
            }, function(results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    var myOptions = {
                        zoom: 8,
                        center: results[0].geometry.location,
                        mapTypeId: google.maps.MapTypeId.ROADMAP
                    }
                    map = new google.maps.Map(document.getElementById("map"), myOptions);
                    var marker = new google.maps.Marker({
                        map: map,
                        position: results[0].geometry.location
                    });
                }
            });
        }
    }
</script>

    <script async defer
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDoz4QoGE6E0uoOox3eNzL4HfLYs4k56_Q&callback=initMap">
    </script>
                        <!-- End Map -->
                    </section>
                    <!-- /section -->
                
                    <hr>

                </div>
                <!-- /col -->
                
                <aside class="col-lg-4" id="sidebar">
                    <div class="box_detail booking">
                        <div class="price">
                            <span>$<?php echo e($occasions[0]->per_night_rent); ?> <small>/day</small></span>
                            <div class="score"><span>Good<em>350 Reviews</em></span><strong>7.0</strong></div>
                        </div>
                        
                        <div class="form-group" id="input_date">
                            <input class="form-control" type="text" name="daterange" placeholder="When..">
                            <i class="icon_calendar"></i>
                        </div>

                        <div class="form-group" id="input_date">
                            <input class="form-control" type="number" name="menbers" placeholder="Total Members">
                            <!-- <i class="icon_calendar"></i> -->
                        </div>
                        
                        <a href="/renterDash" class=" add_top_30 btn_1 full-width purchase">Book now</a>
                        <div class="text-center"><small>No money charged in this step</small></div>
                    </div>
                    <ul class="share-buttons">
                    <li><a class="fb-share" href="#0"><i class="social_facebook"></i> Share</a></li>
                    <li><a class="twitter-share" href="#0"><i class="social_twitter"></i> Tweet</a></li>
                    <li><a class="gplus-share" href="#0"><i class="social_googleplus"></i> Share</a></li>
                </ul>
                </aside>
            </div>
            <!-- /row -->
        </div>
        <!-- /container -->
    </div>
    <!-- /bg_color_1 -->
</main>

<script>
    $(function() {
        $('input[name="daterange"]').daterangepicker({
            opens: 'left'
        }, function(start, end, label) {
            console.log("A new date selection was made: " + start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD'));
        });
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>